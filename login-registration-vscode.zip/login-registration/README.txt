LOGIN & REGISTRATION - REACT + VITE

1. Extract this ZIP file.
2. Open the extracted "login-registration" folder in VS Code.
3. Open Terminal > New Terminal.
4. Run: npm install
5. Run: npm run dev
6. Open the localhost address shown in the terminal (usually http://localhost:5173).

Files:
- index.html       Main HTML page
- src/main.jsx     React entry point
- src/App.jsx      Login and registration logic
- src/App.css      Form styling
- src/index.css    Global styling

Note: This is a frontend demo. It stores user details, including passwords,
in browser Local Storage. Do not use this approach for real accounts.
